#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

// Structure to store user information
struct User {
    string username;
    string password;
    string name;
    string email;
    // Add more user information fields as needed
    string vaccinationStatus; // Added vaccination status field
};

// Structure to store COVID-19 test records
struct TestRecord {
    string date;
    string result;
    // Add more test record fields as needed
};

// Structure to store vaccine records
struct VaccineRecord {
    string date;
    int dosesReceived;
    // Add more vaccine record fields as needed
};

// Function to create a new user account
void createUserAccount(vector<User>& users) {
    User newUser;
    cout << "Enter username: ";
    cin >> newUser.username;
    cout << "Enter password: ";
    cin >> newUser.password;
    cout << "Enter name: ";
    cin >> newUser.name;
    cout << "Enter email: ";
    cin >> newUser.email;
    // Add more user information fields as needed
    newUser.vaccinationStatus = "Unvaccinated"; // Set default vaccination status

    users.push_back(newUser);
    cout << "User account created successfully!" << endl;
}

// Function to log into the system
bool login(const vector<User>& users, string& loggedInUser) {
    string username, password;
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    for (const auto& user : users) {
        if (user.username == username && user.password == password) {
            loggedInUser = user.username;
            return true;
        }
    }

    return false;
}

// Function to view user details
void viewUserDetails(const User& user) {
    cout << "Name: " << user.name << endl;
    cout << "Email: " << user.email << endl;
    cout << "Vaccination Status: " << user.vaccinationStatus << endl << endl; // Display vaccination status
    // Display more user information fields as needed
}

// Function to view COVID-19 test records
void viewTestRecords(const vector<TestRecord>& testRecords) {
    if (testRecords.empty()) {
        cout << "COVID-19 test records not available." << endl << endl;
    }
    else {
        for (const auto& record : testRecords) {
            cout << "Date: " << record.date << endl;
            cout << "Result: " << record.result << endl;
            // Display more test record fields as needed
            cout << endl;
        }
    }
}

// Function to view vaccine records
void viewVaccineRecords(const vector<VaccineRecord>& vaccineRecords) {
    if (vaccineRecords.empty()) {
        cout << "Vaccine records not available." << endl << endl;
    }
    else {
        for (const auto& record : vaccineRecords) {
            cout << "Date: " << record.date << endl;
            cout << "Doses Received: " << record.dosesReceived << endl;
            // Display more vaccine record fields as needed
            cout << endl;
        }
    }
}

// Function to report issues
void reportIssue(const string& loggedInUser) {
    string issue;
    cout << "Enter the issue you encountered: ";
    cin.ignore();
    getline(cin, issue);

    ofstream logfile("issue_log.txt", ios_base::app);
    if (logfile.is_open()) {
        logfile << "User: " << loggedInUser << "\n";
        logfile << "Issue: " << issue << "\n";
        logfile.close();
        cout << "Issue reported successfully!" << endl;
    }
    else {
        cout << "Unable to open the log file." << endl;
    }
}

// Function to change vaccination status
void changeVaccinationStatus(User& user) {
    string status;
    cout << "Enter the new vaccination status (Unvaccinated/Partial/Completed): ";
    cin >> status;
    user.vaccinationStatus = status;
    cout << "Vaccination status updated successfully!" << endl <<endl;
}

int main() {
    vector<User> users;
    vector<TestRecord> testRecords;
    vector<VaccineRecord> vaccineRecords;
    string loggedInUser;

    int choice;
    while (true) {
        cout << "===== My Covid Record =====" << endl;
        cout << "1. Create Account" << endl;
        cout << "2. Login" << endl;
        cout << "3. View User Details" << endl;
        cout << "4. View COVID-19 Test Records" << endl;
        cout << "5. View Vaccine Records" << endl;
        cout << "6. Report Issue" << endl;
        cout << "7. Change Vaccination Status" << endl;
        cout << "8. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        cout << endl; // Add a new line before reprinting the menu

        switch (choice) {
        case 1:
            createUserAccount(users);
            break;
        case 2:
            if (login(users, loggedInUser)) {
                cout << "Logged in successfully!" << endl << endl;
            }
            else {
                cout << "Invalid username or password. Please try again." << endl;
            }
            break;
        case 3:
            if (!loggedInUser.empty()) {
                viewUserDetails(users[0]); // Pass the first user's details
            }
            else {
                cout << "Please log in first." << endl;
            }
            break;
        case 4:
            if (!loggedInUser.empty()) {
                viewTestRecords(testRecords);
            }
            else {
                cout << "Please log in first." << endl;
            }
            break;
        case 5:
            if (!loggedInUser.empty()) {
                viewVaccineRecords(vaccineRecords);
            }
            else {
                cout << "Please log in first." << endl;
            }
            break;
        case 6:
            if (!loggedInUser.empty()) {
                reportIssue(loggedInUser);
            }
            else {
                cout << "Please log in first." << endl;
            }
            break;
        case 7:
            if (!loggedInUser.empty()) {
                changeVaccinationStatus(users[0]); // Pass the first user's details
            }
            else {
                cout << "Please log in first." << endl;
            }
            break;
        case 8:
            cout << "Exiting program..." << endl;
            return 0;
        default:
            cout << "Invalid choice. Please try again." << endl;
            break;
        }
    }
}
